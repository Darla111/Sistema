from . import db

# Minimal helpers or future ORM models can go here. We use raw SQL queries to reflect
# existing database schema so we avoid modifying DB structure.

def get_areas():
    return db.session.execute('SELECT id, nombre FROM area').mappings().all()
