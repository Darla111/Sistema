import re
import hashlib
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user, UserMixin
from . import database, login_manager

# Patrón de validación para contraseña: $Abc#123
PASSWORD_PATTERN = r'^\$[A-Za-z]{3}#[0-9]{3}$'
NAME_PATTERN = re.compile(r'^[A-Za-z\u00C1\u00C9\u00CD\u00D3\u00DA\u00E1\u00E9\u00ED\u00F3\u00FA\u00D1\u00F1\s]+$')


def is_valid_text(value):
    return bool(NAME_PATTERN.fullmatch(value or ''))

auth_bp = Blueprint('auth', __name__, template_folder='templates')


class User(UserMixin):
    def __init__(self, row):
        self.id = row.get('id_usuario')
        self.nombre = row.get('nombre')
        self.apellidos = row.get('apellidos')
        self.usuario_generado = row.get('usuario_generado')
        self.area_id = row.get('id_area')


@login_manager.user_loader
def load_user(user_id):
    row = database.get_one('SELECT * FROM usuario WHERE id_usuario = %s', (user_id,))
    if row:
        return User(row)
    return None


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario_generado = request.form.get('usuario_generado', '').strip()
        password = request.form.get('password', '')

        if not usuario_generado or not password:
            flash('Rellena todos los campos.', 'danger')
            return redirect(url_for('auth.login'))

        row = database.get_one('SELECT * FROM usuario WHERE usuario_generado = %s', (usuario_generado,))
        if not row:
            flash('Usuario no encontrado.', 'danger')
            return redirect(url_for('auth.login'))

        # compare SHA-256 hash
        pw_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
        if row.get('password_hash') != pw_hash:
            flash('Contraseña incorrecta.', 'danger')
            return redirect(url_for('auth.login'))

        # Manejo de primer ingreso: mostrar pantalla de bienvenida
        user = User(row)
        login_user(user)
        
        if row.get('primer_ingreso') == 1:
            # Redirigir a pantalla de bienvenida en lugar de dashboard
            return redirect(url_for('main.welcome'))
        
        flash(f'✅ Bienvenido, {row.get("nombre")}!', 'success')
        return redirect(url_for('main.dashboard'))

    return render_template('login.html')


@auth_bp.route('/logout')
@login_required
def logout():
    user_name = current_user.nombre
    logout_user()
    flash(f'👋 Hasta luego, {user_name}!', 'info')
    return redirect(url_for('auth.login'))


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Registro institucional de personal nuevo (accesible sin login)"""
    areas = database.query('SELECT id_area, nombre_area FROM area')

    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        apellidos = request.form.get('apellidos', '').strip()
        edad = request.form.get('edad', '').strip()
        area_id = request.form.get('area_id', '').strip()
        password = request.form.get('password', '').strip()

        # Validación: campos obligatorios
        if not (nombre and apellidos and edad and area_id and password):
            flash('⚠️ Todos los campos son obligatorios.', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

        # Validación: nombre y apellidos
        if not is_valid_text(nombre):
            flash('⚠️ El nombre debe contener solo letras y espacios.', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)
        if not is_valid_text(apellidos):
            flash('⚠️ Los apellidos deben contener solo letras y espacios.', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

        # Validación: edad 18-35
        try:
            edad_int = int(edad)
            if edad_int < 18 or edad_int > 35:
                flash('⚠️ La edad debe estar entre 18 y 35 años.', 'danger')
                return render_template('register.html', areas=areas, form_data=request.form)
        except ValueError:
            flash('⚠️ La edad debe ser un número válido.', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

        # Validación: área válida
        area_existe = database.get_one('SELECT id_area FROM area WHERE id_area = %s', (area_id,))
        if not area_existe:
            flash('⚠️ Área no válida.', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

        # Validación: contraseña con formato $Abc#123
        if not re.match(PASSWORD_PATTERN, password):
            flash('⚠️ Formato de contraseña inválido. Debe ser: $Abc#123 ($ + 3 letras + # + 3 números).', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

        # Generar usuario automáticamente: @inicial_nombre.inicial_ap_p.inicial_ap_m_edad
        # Ejemplo: Berenice Chávez Bedolla, 22 años → @b.c.b_22
        parts = apellidos.split()
        ap_p = parts[0] if parts else ''
        ap_m = parts[1] if len(parts) > 1 else ''

        inicial_nombre = nombre[0].lower() if nombre else ''
        inicial_ap_p = ap_p[0].lower() if ap_p else ''
        inicial_ap_m = ap_m[0].lower() if ap_m else 'x'

        usuario_generado = f"@{inicial_nombre}.{inicial_ap_p}.{inicial_ap_m}_{edad_int}"

        # Validar que el usuario generado NO exista
        existe = database.get_one('SELECT id_usuario FROM usuario WHERE usuario_generado = %s', (usuario_generado,))
        if existe:
            flash(f'⚠️ El usuario {usuario_generado} ya existe. Ajusta nombre, apellidos o edad.', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

        # Hash SHA-256 de contraseña
        password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()

        # Insertar nuevo usuario
        try:
            insert_sql = (
                'INSERT INTO usuario (nombre, apellidos, edad, id_area, usuario_generado, password_hash, primer_ingreso) '
                'VALUES (%s, %s, %s, %s, %s, %s, 1)'
            )
            database.execute(insert_sql, (nombre, apellidos, edad_int, area_id, usuario_generado, password_hash))
            flash(f'✅ Usuario registrado correctamente: {usuario_generado}', 'success')
            return redirect(url_for('main.dashboard'))
        except Exception as e:
            flash(f'❌ Error al registrar: {str(e)}', 'danger')
            return render_template('register.html', areas=areas, form_data=request.form)

    return render_template('register.html', areas=areas)
