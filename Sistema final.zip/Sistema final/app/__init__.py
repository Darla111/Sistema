from flask import Flask
from flask_login import current_user
from flask_login import LoginManager
from config import Config
from . import database

login_manager = LoginManager()
login_manager.login_view = 'auth.login'


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # initialize database pool
    database.init_app(app)

    login_manager.init_app(app)

    @app.context_processor
    def inject_user_context():
        if not current_user or not current_user.is_authenticated:
            return {}
        area = database.get_one('SELECT nombre_area FROM area WHERE id_area = %s', (current_user.area_id,))
        area_name = area['nombre_area'] if area else ''
        return {
            'user_area_name': area_name,
            'is_admin': current_user.area_id == 4
        }

    with app.app_context():
        # Import blueprints
        from .auth import auth_bp
        from .routes import main_bp

        app.register_blueprint(auth_bp)
        app.register_blueprint(main_bp)

        return app
