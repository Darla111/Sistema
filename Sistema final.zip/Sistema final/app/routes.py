from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from . import database
import re

main_bp = Blueprint('main', __name__, template_folder='templates')

NAME_PATTERN = re.compile(r'^[A-Za-z\u00C1\u00C9\u00CD\u00D3\u00DA\u00E1\u00E9\u00ED\u00F3\u00FA\u00D1\u00F1\s]+$')


def is_valid_text(value):
    return bool(NAME_PATTERN.fullmatch(value or ''))


def sync_stock_alert(producto_id, nombre_producto, stock_actual, stock_minimo):
    """Crear o resolver alerta de stock bajo segun niveles actuales."""
    if stock_actual <= stock_minimo:
        nivel = 'CRITICA' if stock_actual == 0 else 'ADVERTENCIA'
        mensaje = (
            f'Stock agotado: {nombre_producto}'
            if stock_actual == 0
            else f'Stock bajo: {nombre_producto} ({stock_actual} <= {stock_minimo})'
        )
        existing = database.get_one(
            '''SELECT id_alerta FROM alerta
               WHERE id_producto = %s AND tipo_alerta = 'STOCK_BAJO' AND estado = 'ACTIVA' ''',
            (producto_id,)
        )
        if not existing:
            database.execute(
                '''INSERT INTO alerta (id_producto, tipo_alerta, mensaje, nivel, estado, atendida)
                   VALUES (%s, 'STOCK_BAJO', %s, %s, 'ACTIVA', 0)''',
                (producto_id, mensaje, nivel)
            )
        else:
            database.execute(
                '''UPDATE alerta SET mensaje = %s, nivel = %s
                   WHERE id_alerta = %s''',
                (mensaje, nivel, existing['id_alerta'])
            )
    else:
        database.execute(
            '''UPDATE alerta SET atendida = 1
               WHERE id_producto = %s AND tipo_alerta = 'STOCK_BAJO' AND atendida = 0''',
            (producto_id,)
        )
        database.execute(
            '''UPDATE alerta SET estado = 'RESUELTA'
               WHERE id_producto = %s AND tipo_alerta = 'STOCK_BAJO' AND estado = 'ACTIVA' ''',
            (producto_id,)
        )
        # Crear alerta informativa de reposicion si aplica
        recent_info = database.get_one(
            '''SELECT id_alerta FROM alerta
               WHERE id_producto = %s AND nivel = 'INFORMATIVA'
                 AND DATE(fecha_alerta) = CURDATE()''',
            (producto_id,)
        )
        prior_issue = database.get_one(
            '''SELECT id_alerta FROM alerta
               WHERE id_producto = %s AND tipo_alerta = 'STOCK_BAJO'
                 AND DATE(fecha_alerta) = CURDATE()''',
            (producto_id,)
        )
        if not recent_info and prior_issue:
            database.execute(
                '''INSERT INTO alerta (id_producto, tipo_alerta, mensaje, nivel, estado, atendida)
                   VALUES (%s, 'STOCK_BAJO', %s, 'INFORMATIVA', 'ACTIVA', 0)''',
                (producto_id, f'Producto repuesto: {nombre_producto}')
            )


def can_user_sell(user):
    """Determina si el usuario puede vender por area Ventas o rol VENDEDOR."""
    area = database.get_one(
        'SELECT nombre_area FROM area WHERE id_area = %s',
        (user.area_id,)
    )
    if area and area.get('nombre_area') == 'Ventas':
        return True
    empleado = database.get_one(
        'SELECT rol FROM empleado WHERE nombre = %s AND apellidos = %s AND activo = 1',
        (user.nombre, user.apellidos)
    )
    return bool(empleado and empleado.get('rol') == 'VENDEDOR')


def get_area_name(user):
    area = database.get_one('SELECT nombre_area FROM area WHERE id_area = %s', (user.area_id,))
    return area['nombre_area'] if area else ''


def require_area(*areas):
    if current_user.area_id == 4:
        return True
    return get_area_name(current_user) in areas


def get_user_employee_role(user):
    empleado = database.get_one(
        'SELECT rol FROM empleado WHERE nombre = %s AND apellidos = %s AND activo = 1',
        (user.nombre, user.apellidos)
    )
    return empleado['rol'] if empleado else 'EMPLEADO'


def is_admin_user(user):
    return user.area_id == 4 or get_user_employee_role(user) == 'ADMIN'


def is_administrativo_user(user):
    return get_area_name(user) == 'Administracion' and not is_admin_user(user)


def ensure_operational_alerts(inactividad_dias=30):
    """Genera alertas automáticas de inactividad y mantiene coherencia de stock."""
    productos = database.query("SELECT id_producto, nombre_producto, stock_actual, stock_minimo FROM producto WHERE estado = 'ACTIVO'")
    for p in productos:
        sync_stock_alert(p['id_producto'], p['nombre_producto'], p['stock_actual'], p['stock_minimo'])

    # productos sin movimientos por X días
    inactivos = database.query(
        '''SELECT p.id_producto, p.nombre_producto
           FROM producto p
           LEFT JOIN movimiento m ON m.id_producto = p.id_producto
           WHERE p.estado = 'ACTIVO'
           GROUP BY p.id_producto, p.nombre_producto
           HAVING MAX(m.fecha_movimiento) IS NULL
               OR MAX(m.fecha_movimiento) < DATE_SUB(NOW(), INTERVAL %s DAY)''',
        (inactividad_dias,)
    )
    for p in inactivos:
        existing = database.get_one(
            '''SELECT id_alerta FROM alerta
               WHERE id_producto = %s AND tipo_alerta = 'CADUCIDAD' AND estado = 'ACTIVA' ''',
            (p['id_producto'],)
        )
        if not existing:
            database.execute(
                '''INSERT INTO alerta (id_producto, tipo_alerta, mensaje, nivel, estado, atendida)
                   VALUES (%s, 'CADUCIDAD', %s, 'INFORMATIVA', 'ACTIVA', 0)''',
                (p['id_producto'], f'Sin movimientos recientes: {p["nombre_producto"]}')
            )

    # Alertas de sistema por inconsistencias
    inconsistencias = database.query(
        "SELECT id_producto, nombre_producto, stock_actual FROM producto WHERE stock_actual < 0"
    )
    for p in inconsistencias:
        existing = database.get_one(
            '''SELECT id_alerta FROM alerta
               WHERE id_producto = %s AND nivel = 'SISTEMA' AND estado = 'ACTIVA' ''',
            (p['id_producto'],)
        )
        if not existing:
            database.execute(
                '''INSERT INTO alerta (id_producto, tipo_alerta, mensaje, nivel, estado, atendida)
                   VALUES (%s, 'CADUCIDAD', %s, 'SISTEMA', 'ACTIVA', 0)''',
                (p['id_producto'], f'Inconsistencia de stock: {p["nombre_producto"]} ({p["stock_actual"]})')
            )


@main_bp.route('/')
def index():
    return redirect(url_for('auth.login'))


@main_bp.route('/welcome')
@login_required
def welcome():
    """Pantalla de bienvenida para usuario en primer ingreso"""
    # Obtener información del área del usuario
    user_area = database.get_one(
        'SELECT id_area, nombre_area FROM area WHERE id_area = %s',
        (current_user.area_id,)
    )
    
    # Marcar primer_ingreso como completado
    database.execute(
        'UPDATE usuario SET primer_ingreso = 0 WHERE id_usuario = %s',
        (current_user.id,)
    )
    
    flash(f'✅ Bienvenido al sistema, {current_user.nombre}!', 'success')
    return render_template('welcome.html', user_area=user_area)


@main_bp.route('/test-db')
def test_db():
    """
    Ruta de prueba para validar la conexión a la base de datos.
    Ejecuta: SELECT COUNT(*) AS total FROM producto
    Requiere usuario: BereniceCB, contraseña: 1234
    Base de datos: sistema_gestion_empresarial
    """
    try:
        result = database.get_one('SELECT COUNT(*) AS total FROM producto')
        if result:
            return jsonify({
                'status': 'success',
                'message': 'Conexión a la base de datos exitosa',
                'usuario': 'BereniceCB',
                'database': 'sistema_gestion_empresarial',
                'result': {
                    'total_productos': result['total']
                }
            }), 200
        else:
            return jsonify({
                'status': 'error',
                'message': 'No se pudo obtener el resultado de la consulta',
            }), 500
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error de conexión a la base de datos: {str(e)}',
        }), 500


@main_bp.route('/dashboard')
@login_required
def dashboard():
    ensure_operational_alerts()
    area_name = get_area_name(current_user)
    # KPIs
    if current_user.area_id == 4 or area_name == 'Administracion':
        total_products_row = database.get_one("SELECT COUNT(*) AS c FROM producto WHERE estado = 'ACTIVO'")
        total_products = total_products_row['c'] if total_products_row else 0
        stock_total_row = database.get_one("SELECT COALESCE(SUM(stock_actual),0) AS c FROM producto WHERE estado = 'ACTIVO'")
        stock_total = stock_total_row['c'] if stock_total_row else 0
        movimientos_hoy_row = database.get_one(
            "SELECT COUNT(*) AS c FROM movimiento WHERE DATE(fecha_movimiento) = CURDATE()"
        )
        movimientos_hoy = movimientos_hoy_row['c'] if movimientos_hoy_row else 0
        ventas_hoy_row = database.get_one(
            '''SELECT COALESCE(SUM(m.cantidad),0) AS c
               FROM movimiento m
               JOIN usuario u ON u.id_usuario = m.id_usuario
               LEFT JOIN empleado e ON e.nombre = u.nombre AND e.apellidos = u.apellidos AND e.activo = 1
               LEFT JOIN area a ON a.id_area = u.id_area
               WHERE m.tipo_movimiento = 'VENTA'
                 AND DATE(m.fecha_movimiento) = CURDATE()
                 AND (a.nombre_area = 'Ventas' OR e.rol = 'VENDEDOR')'''
        )
        ventas_hoy = ventas_hoy_row['c'] if ventas_hoy_row else 0
        active_alerts_row = database.get_one("SELECT COUNT(*) AS c FROM alerta WHERE estado = 'ACTIVA'")
        active_alerts = active_alerts_row['c'] if active_alerts_row else 0
        critical_alerts_row = database.get_one("SELECT COUNT(*) AS c FROM alerta WHERE estado = 'ACTIVA' AND nivel = 'CRITICA'")
        critical_alerts = critical_alerts_row['c'] if critical_alerts_row else 0
        risk_products_row = database.get_one("SELECT COUNT(*) AS c FROM producto WHERE estado = 'ACTIVO' AND stock_actual <= stock_minimo")
        risk_products = risk_products_row['c'] if risk_products_row else 0
        resolved_today_row = database.get_one("SELECT COUNT(*) AS c FROM alerta WHERE estado = 'RESUELTA' AND DATE(fecha_alerta) = CURDATE()")
        resolved_today = resolved_today_row['c'] if resolved_today_row else 0
    elif area_name == 'Ventas':
        total_products_row = database.get_one("SELECT COUNT(*) AS c FROM producto WHERE estado = 'ACTIVO'")
        total_products = total_products_row['c'] if total_products_row else 0
        stock_total_row = database.get_one("SELECT COALESCE(SUM(stock_actual),0) AS c FROM producto WHERE estado = 'ACTIVO'")
        stock_total = stock_total_row['c'] if stock_total_row else 0
        movimientos_hoy_row = database.get_one(
            "SELECT COUNT(*) AS c FROM movimiento WHERE DATE(fecha_movimiento) = CURDATE() AND id_usuario = %s",
            (current_user.id,)
        )
        movimientos_hoy = movimientos_hoy_row['c'] if movimientos_hoy_row else 0
        ventas_hoy_row = database.get_one(
            "SELECT COALESCE(SUM(cantidad),0) AS c FROM movimiento WHERE tipo_movimiento = 'VENTA' AND DATE(fecha_movimiento) = CURDATE() AND id_usuario = %s",
            (current_user.id,)
        )
        ventas_hoy = ventas_hoy_row['c'] if ventas_hoy_row else 0
        active_alerts_row = database.get_one(
            '''SELECT COUNT(*) AS c
               FROM alerta a
               JOIN movimiento m ON m.id_producto = a.id_producto
               WHERE a.estado = 'ACTIVA' AND m.id_usuario = %s''',
            (current_user.id,)
        )
        active_alerts = active_alerts_row['c'] if active_alerts_row else 0
        critical_alerts_row = database.get_one(
            '''SELECT COUNT(*) AS c
               FROM alerta a
               JOIN movimiento m ON m.id_producto = a.id_producto
               WHERE a.estado = 'ACTIVA' AND a.nivel = 'CRITICA' AND m.id_usuario = %s''',
            (current_user.id,)
        )
        critical_alerts = critical_alerts_row['c'] if critical_alerts_row else 0
        risk_products_row = database.get_one("SELECT COUNT(*) AS c FROM producto WHERE estado = 'ACTIVO' AND stock_actual <= stock_minimo")
        risk_products = risk_products_row['c'] if risk_products_row else 0
        resolved_today_row = database.get_one(
            "SELECT COUNT(*) AS c FROM alerta WHERE estado = 'RESUELTA' AND DATE(fecha_alerta) = CURDATE()"
        )
        resolved_today = resolved_today_row['c'] if resolved_today_row else 0
    else:
        total_products_row = database.get_one("SELECT COUNT(*) AS c FROM producto WHERE estado = 'ACTIVO'")
        total_products = total_products_row['c'] if total_products_row else 0
        stock_total_row = database.get_one("SELECT COALESCE(SUM(stock_actual),0) AS c FROM producto WHERE estado = 'ACTIVO'")
        stock_total = stock_total_row['c'] if stock_total_row else 0
        movimientos_hoy_row = database.get_one(
            "SELECT COUNT(*) AS c FROM movimiento WHERE DATE(fecha_movimiento) = CURDATE() AND tipo_movimiento IN ('ENTRADA','SALIDA')"
        )
        movimientos_hoy = movimientos_hoy_row['c'] if movimientos_hoy_row else 0
        ventas_hoy = 0
        active_alerts_row = database.get_one(
            "SELECT COUNT(*) AS c FROM alerta WHERE estado = 'ACTIVA' AND nivel IN ('CRITICA','ADVERTENCIA','INFORMATIVA')"
        )
        active_alerts = active_alerts_row['c'] if active_alerts_row else 0
        critical_alerts_row = database.get_one(
            "SELECT COUNT(*) AS c FROM alerta WHERE estado = 'ACTIVA' AND nivel = 'CRITICA'"
        )
        critical_alerts = critical_alerts_row['c'] if critical_alerts_row else 0
        risk_products_row = database.get_one("SELECT COUNT(*) AS c FROM producto WHERE estado = 'ACTIVO' AND stock_actual <= stock_minimo")
        risk_products = risk_products_row['c'] if risk_products_row else 0
        resolved_today_row = database.get_one("SELECT COUNT(*) AS c FROM alerta WHERE estado = 'RESUELTA' AND DATE(fecha_alerta) = CURDATE()")
        resolved_today = resolved_today_row['c'] if resolved_today_row else 0

    # Charts data
    movimientos_por_dia = database.query('''
        SELECT DATE(fecha_movimiento) AS fecha, COUNT(*) AS total_movimientos, SUM(cantidad) AS total_cantidad
        FROM movimiento
        GROUP BY DATE(fecha_movimiento)
        ORDER BY fecha DESC
        LIMIT 7
    ''')
    movimientos_por_producto = database.query('''
        SELECT p.nombre_producto, SUM(m.cantidad) AS total_movido
        FROM movimiento m
        JOIN producto p ON p.id_producto = m.id_producto
        GROUP BY p.nombre_producto
        ORDER BY total_movido DESC
        LIMIT 7
    ''')
    ventas_por_empleado = database.query('''
        SELECT CONCAT(u.nombre, ' ', u.apellidos) AS empleado, SUM(m.cantidad) AS total_ventas
        FROM movimiento m
        JOIN usuario u ON u.id_usuario = m.id_usuario
        LEFT JOIN empleado e ON e.nombre = u.nombre AND e.apellidos = u.apellidos AND e.activo = 1
        LEFT JOIN area a ON a.id_area = u.id_area
        WHERE m.tipo_movimiento = 'VENTA'
          AND (a.nombre_area = 'Ventas' OR e.rol = 'VENDEDOR')
        GROUP BY u.nombre, u.apellidos
        ORDER BY total_ventas DESC
        LIMIT 7
    ''')
    productos_menor_stock = database.query('''
        SELECT nombre_producto, stock_actual, stock_minimo
        FROM producto
        WHERE estado = 'ACTIVO'
        ORDER BY stock_actual ASC
        LIMIT 7
    ''')
    alertas_criticas = database.query('''
        SELECT a.id_alerta, p.nombre_producto, a.mensaje, a.fecha_alerta, a.nivel
        FROM alerta a
        JOIN producto p ON a.id_producto = p.id_producto
        WHERE a.estado = 'ACTIVA' AND a.nivel = 'CRITICA'
        ORDER BY a.fecha_alerta DESC
        LIMIT 5
    ''')
    total_alertas_row = database.get_one("SELECT COUNT(*) AS c FROM alerta WHERE estado = 'ACTIVA'")
    total_alertas = total_alertas_row['c'] if total_alertas_row else 0
    riesgo_sistema = 0
    if total_products > 0:
        riesgo_sistema = int((risk_products / total_products) * 100)

    return render_template(
        'dashboard.html',
        total_products=total_products,
        stock_total=stock_total,
        movimientos_hoy=movimientos_hoy,
        ventas_hoy=ventas_hoy,
        active_alerts=active_alerts,
        critical_alerts=critical_alerts,
        risk_products=risk_products,
        resolved_today=resolved_today,
        movimientos_por_dia=movimientos_por_dia,
        movimientos_por_producto=movimientos_por_producto,
        ventas_por_empleado=ventas_por_empleado,
        productos_menor_stock=productos_menor_stock,
        alertas_criticas=alertas_criticas,
        riesgo_sistema=riesgo_sistema
    )


@main_bp.route('/empleados')
@login_required
def empleados():
    if not require_area('Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    area_id = request.args.get('area_id')
    base_sql = '''
        SELECT e.*, a.nombre_area,
               COALESCE(v.total_ventas, 0) AS total_ventas,
               CASE WHEN a.nombre_area = 'Ventas' OR e.rol = 'VENDEDOR' THEN 1 ELSE 0 END AS puede_vender
        FROM empleado e
        LEFT JOIN area a ON e.id_area = a.id_area
        LEFT JOIN (
            SELECT u.nombre, u.apellidos, SUM(m.cantidad) AS total_ventas
            FROM movimiento m
            JOIN usuario u ON m.id_usuario = u.id_usuario
            WHERE m.tipo_movimiento = 'VENTA' AND m.resultado = 'APROBADO'
            GROUP BY u.nombre, u.apellidos
        ) v ON v.nombre = e.nombre AND v.apellidos = e.apellidos
        WHERE e.activo = 1
    '''
    if area_id:
        rows = database.query(base_sql + ' AND e.id_area = %s', (area_id,))
    else:
        rows = database.query(base_sql)
    areas = database.query('SELECT id_area, nombre_area FROM area')
    return render_template('empleados.html', empleados=rows, areas=areas,
                           is_admin=is_admin_user(current_user),
                           is_administrativo=is_administrativo_user(current_user))


@main_bp.route('/empleado/new', methods=['GET', 'POST'])
@login_required
def empleado_new():
    if not require_area('Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    areas = database.query('SELECT id_area, nombre_area FROM area')
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        apellidos = request.form.get('apellidos', '').strip()
        edad = request.form.get('edad', '').strip()
        area_id = request.form.get('area_id')
        rol = request.form.get('rol', '').strip()
        if not (nombre and apellidos and edad and area_id):
            flash('Todos los campos son obligatorios.', 'danger')
            return redirect(url_for('main.empleado_new'))
        if not is_valid_text(nombre):
            flash('El nombre debe contener solo letras y espacios.', 'danger')
            return redirect(url_for('main.empleado_new'))
        if not is_valid_text(apellidos):
            flash('Los apellidos deben contener solo letras y espacios.', 'danger')
            return redirect(url_for('main.empleado_new'))
        try:
            edad_int = int(edad)
            if edad_int < 18:
                flash('La edad debe ser mayor a 17 años.', 'danger')
                return redirect(url_for('main.empleado_new'))
        except ValueError:
            flash('Edad inválida.', 'danger')
            return redirect(url_for('main.empleado_new'))
        if rol not in ('ADMIN', 'EMPLEADO', 'VENDEDOR'):
            flash('Rol inválido.', 'danger')
            return redirect(url_for('main.empleado_new'))
        if not is_admin_user(current_user) and rol == 'ADMIN':
            flash('No tienes permiso para asignar rol ADMIN.', 'danger')
            return redirect(url_for('main.empleado_new'))

        database.execute('''INSERT INTO empleado (nombre, apellidos, edad, id_area, rol, puesto, activo)
                            VALUES (%s,%s,%s,%s,%s,%s,1)''',
                 (nombre, apellidos, edad_int, area_id, rol, rol))
        flash('Empleado creado.', 'success')
        return redirect(url_for('main.empleados'))

    return render_template('empleado_form.html', areas=areas,
                           is_admin=is_admin_user(current_user))


@main_bp.route('/empleado/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def empleado_edit(id):
    if not require_area('Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    row = database.get_one('SELECT * FROM empleado WHERE id_empleado = %s', (id,))
    if not row:
        flash('Empleado no encontrado.', 'danger')
        return redirect(url_for('main.empleados'))
    areas = database.query('SELECT id_area, nombre_area FROM area')
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        apellidos = request.form.get('apellidos', '').strip()
        edad = request.form.get('edad', '').strip()
        area_id = request.form.get('area_id')
        rol = request.form.get('rol', '').strip()
        if not (nombre and apellidos and edad and area_id):
            flash('Todos los campos son obligatorios.', 'danger')
            return redirect(url_for('main.empleado_edit', id=id))
        if not is_valid_text(nombre):
            flash('El nombre debe contener solo letras y espacios.', 'danger')
            return redirect(url_for('main.empleado_edit', id=id))
        if not is_valid_text(apellidos):
            flash('Los apellidos deben contener solo letras y espacios.', 'danger')
            return redirect(url_for('main.empleado_edit', id=id))
        try:
            edad_int = int(edad)
            if edad_int < 18:
                flash('La edad debe ser mayor a 17 años.', 'danger')
                return redirect(url_for('main.empleado_edit', id=id))
        except ValueError:
            flash('Edad inválida.', 'danger')
            return redirect(url_for('main.empleado_edit', id=id))
        if rol not in ('ADMIN', 'EMPLEADO', 'VENDEDOR'):
            flash('Rol inválido.', 'danger')
            return redirect(url_for('main.empleado_edit', id=id))
        if is_administrativo_user(current_user):
            # administrativo no puede cambiar rol
            rol = row['rol']
        if not is_admin_user(current_user) and rol == 'ADMIN':
            flash('No tienes permiso para asignar rol ADMIN.', 'danger')
            return redirect(url_for('main.empleado_edit', id=id))

        database.execute('''UPDATE empleado
                            SET nombre=%s, apellidos=%s, edad=%s, id_area=%s, rol=%s, puesto=%s
                            WHERE id_empleado=%s''',
                 (nombre, apellidos, edad_int, area_id, rol, rol, id))
        flash('Empleado actualizado.', 'success')
        return redirect(url_for('main.empleados'))

    return render_template('empleado_form.html', empleado=row, areas=areas,
                           is_admin=is_admin_user(current_user))


@main_bp.route('/empleado/delete/<int:id>', methods=['POST'])
@login_required
def empleado_delete(id):
    if not require_area('Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    if not is_admin_user(current_user):
        flash('No tienes permiso para eliminar empleados.', 'danger')
        return redirect(url_for('main.empleados'))
    row = database.get_one('SELECT * FROM empleado WHERE id_empleado = %s', (id,))
    if not row:
        flash('Empleado no encontrado.', 'danger')
        return redirect(url_for('main.empleados'))
    if row.get('rol') == 'ADMIN':
        flash('No puedes eliminar un empleado critico (ADMIN).', 'danger')
        return redirect(url_for('main.empleados'))
    database.execute('UPDATE empleado SET activo = 0 WHERE id_empleado = %s', (id,))
    flash('Empleado inactivado.', 'info')
    return redirect(url_for('main.empleados'))


@main_bp.route('/productos')
@login_required
def productos():
    if not require_area('Ventas', 'Almacen', 'Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    rows = database.query("SELECT * FROM producto WHERE estado = 'ACTIVO'")
    return render_template('productos.html', productos=rows)


@main_bp.route('/producto/new', methods=['GET', 'POST'])
@login_required
def producto_new():
    if not require_area('Almacen', 'Administracion'):
        flash('No tienes permiso para crear productos.', 'danger')
        return redirect(url_for('main.productos'))
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        stock_minimo = request.form.get('stock_minimo', '0').strip()
        if not nombre:
            flash('El nombre del producto es obligatorio.', 'danger')
            return redirect(url_for('main.producto_new'))
        if not is_valid_text(nombre):
            flash('El nombre del producto debe contener solo letras y espacios.', 'danger')
            return redirect(url_for('main.producto_new'))
        try:
            sm = int(stock_minimo)
        except ValueError:
            flash('Stock debe ser numérico.', 'danger')
            return redirect(url_for('main.producto_new'))
        if sm < 0:
            flash('Stock mínimo inválido.', 'danger')
            return redirect(url_for('main.producto_new'))

        producto_id = database.execute(
            'INSERT INTO producto (nombre_producto, stock_actual, stock_minimo, estado) VALUES (%s,%s,%s,%s)',
            (nombre, 0, sm, 'ACTIVO')
        )
        sync_stock_alert(producto_id, nombre, 0, sm)
        flash('Producto creado.', 'success')
        return redirect(url_for('main.productos'))

    return render_template('producto_form.html')


@main_bp.route('/producto/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def producto_edit(id):
    if not require_area('Almacen', 'Administracion'):
        flash('No tienes permiso para editar productos.', 'danger')
        return redirect(url_for('main.productos'))
    row = database.get_one('SELECT * FROM producto WHERE id_producto = %s', (id,))
    if not row:
        flash('Producto no encontrado.', 'danger')
        return redirect(url_for('main.productos'))
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        if not nombre:
            flash('El nombre del producto es obligatorio.', 'danger')
            return redirect(url_for('main.producto_edit', id=id))
        if not is_valid_text(nombre):
            flash('El nombre del producto debe contener solo letras y espacios.', 'danger')
            return redirect(url_for('main.producto_edit', id=id))
        try:
            sm = int(request.form.get('stock_minimo', '0'))
        except ValueError:
            flash('Stock debe ser numérico.', 'danger')
            return redirect(url_for('main.producto_edit', id=id))
        if sm < 0:
            flash('Stock mínimo inválido.', 'danger')
            return redirect(url_for('main.producto_edit', id=id))

        database.execute('UPDATE producto SET nombre_producto=%s, stock_minimo=%s WHERE id_producto=%s',
                 (nombre, sm, id))
        sync_stock_alert(id, nombre, row['stock_actual'], sm)
        flash('Producto actualizado.', 'success')
        return redirect(url_for('main.productos'))

    return render_template('producto_form.html', producto=row)


@main_bp.route('/producto/delete/<int:id>', methods=['POST'])
@login_required
def producto_delete(id):
    if not require_area('Almacen', 'Administracion'):
        flash('No tienes permiso para eliminar productos.', 'danger')
        return redirect(url_for('main.productos'))
    movimientos = database.get_one('SELECT COUNT(*) AS c FROM movimiento WHERE id_producto = %s', (id,))
    if movimientos and movimientos['c'] > 0:
        database.execute("UPDATE producto SET estado = 'INACTIVO' WHERE id_producto = %s", (id,))
        database.execute(
            "UPDATE alerta SET atendida = 1, estado = 'RESUELTA' WHERE id_producto = %s AND atendida = 0",
            (id,)
        )
        flash('Producto inactivado (tiene movimientos registrados).', 'info')
    else:
        database.execute("UPDATE producto SET estado = 'INACTIVO' WHERE id_producto = %s", (id,))
        database.execute(
            "UPDATE alerta SET atendida = 1, estado = 'RESUELTA' WHERE id_producto = %s AND atendida = 0",
            (id,)
        )
        flash('Producto inactivado.', 'info')
    return redirect(url_for('main.productos'))


@main_bp.route('/movimientos', methods=['GET', 'POST'])
@login_required
def movimientos():
    if not require_area('Ventas', 'Almacen', 'Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    producto_id_filtro = request.args.get('producto_id')
    area_name = get_area_name(current_user)
    productos = database.query("SELECT id_producto, nombre_producto, stock_actual FROM producto WHERE estado = 'ACTIVO'")
    if request.method == 'POST' and area_name in ('Ventas', 'Almacen'):
        producto_id = request.form.get('producto_id')
        tipo = request.form.get('tipo_movimiento')
        cantidad = request.form.get('cantidad')
        try:
            cantidad_i = int(cantidad)
            if cantidad_i <= 0:
                flash('La cantidad debe ser mayor a 0.', 'danger')
                return redirect(url_for('main.movimientos'))
        except ValueError:
            flash('Cantidad inválida.', 'danger')
            return redirect(url_for('main.movimientos'))

        prod = database.get_one('SELECT * FROM producto WHERE id_producto = %s', (producto_id,))
        if not prod:
            flash('Producto no encontrado.', 'danger')
            return redirect(url_for('main.movimientos'))
        if prod.get('estado') != 'ACTIVO':
            flash('Producto inactivo. No se puede registrar movimientos.', 'danger')
            return redirect(url_for('main.movimientos'))

        if tipo not in ('ENTRADA', 'SALIDA', 'VENTA'):
            flash('Tipo de movimiento inválido.', 'danger')
            return redirect(url_for('main.movimientos'))
        if area_name == 'Ventas' and tipo != 'VENTA':
            flash('Solo puedes registrar ventas.', 'danger')
            return redirect(url_for('main.movimientos'))
        if area_name == 'Almacen' and tipo != 'ENTRADA':
            flash('Solo puedes registrar entradas en almacen.', 'danger')
            return redirect(url_for('main.movimientos'))
        if tipo == 'VENTA' and not can_user_sell(current_user):
            flash('Este usuario no tiene permiso para registrar ventas.', 'danger')
            return redirect(url_for('main.movimientos'))
        if tipo in ('SALIDA', 'VENTA') and cantidad_i > prod['stock_actual']:
            if tipo == 'VENTA':
                nivel = 'CRITICA' if prod['stock_actual'] == 0 else 'ADVERTENCIA'
                mensaje = f'Venta bloqueada por bajo stock: {prod["nombre_producto"]} (solicita {current_user.nombre} {current_user.apellidos})'
                existing = database.get_one(
                    '''SELECT id_alerta FROM alerta
                       WHERE id_producto = %s AND tipo_alerta = 'STOCK_BAJO' AND estado = 'ACTIVA' ''',
                    (producto_id,)
                )
                if not existing:
                    database.execute(
                        '''INSERT INTO alerta (id_producto, tipo_alerta, mensaje, nivel, estado, atendida)
                           VALUES (%s, 'STOCK_BAJO', %s, %s, 'ACTIVA', 0)''',
                        (producto_id, mensaje, nivel)
                    )
                else:
                    database.execute(
                        '''UPDATE alerta SET mensaje = %s, nivel = %s
                           WHERE id_alerta = %s''',
                        (mensaje, nivel, existing['id_alerta'])
                    )
            flash('No hay suficiente stock para realizar la operación.', 'danger')
            return redirect(url_for('main.movimientos'))

        # update stock
        if tipo == 'ENTRADA':
            new_stock = prod['stock_actual'] + cantidad_i
        else:
            new_stock = prod['stock_actual'] - cantidad_i

        database.execute('UPDATE producto SET stock_actual = %s WHERE id_producto = %s', (new_stock, producto_id))

        # insert movimiento
        database.execute('''INSERT INTO movimiento
                            (id_producto, id_usuario, tipo_movimiento, cantidad, resultado)
                            VALUES (%s,%s,%s,%s,%s)''',
                 (producto_id, current_user.id, tipo, cantidad_i, 'APROBADO'))
        sync_stock_alert(producto_id, prod['nombre_producto'], new_stock, prod['stock_minimo'])
        flash('Movimiento registrado.', 'success')
        return redirect(url_for('main.movimientos'))

    if area_name == 'Ventas':
        movimientos = database.query('''
            SELECT m.*, p.nombre_producto AS producto
            FROM movimiento m
            LEFT JOIN producto p ON p.id_producto = m.id_producto
            WHERE m.id_usuario = %s AND m.tipo_movimiento = 'VENTA'
            ORDER BY m.id_movimiento DESC LIMIT 100
        ''', (current_user.id,))
    elif area_name == 'Almacen':
        movimientos = database.query('''
            SELECT m.*, p.nombre_producto AS producto
            FROM movimiento m
            LEFT JOIN producto p ON p.id_producto = m.id_producto
            WHERE m.tipo_movimiento IN ('ENTRADA','SALIDA')
            ORDER BY m.id_movimiento DESC LIMIT 100
        ''')
    elif producto_id_filtro:
        movimientos = database.query('''
            SELECT m.*, p.nombre_producto AS producto
            FROM movimiento m
            LEFT JOIN producto p ON p.id_producto = m.id_producto
            WHERE m.id_producto = %s
            ORDER BY m.id_movimiento DESC LIMIT 100
        ''', (producto_id_filtro,))
    else:
        movimientos = database.query('''
            SELECT m.*, p.nombre_producto AS producto
            FROM movimiento m
            LEFT JOIN producto p ON p.id_producto = m.id_producto
            ORDER BY m.id_movimiento DESC LIMIT 100
        ''')
    return render_template('movimientos.html', productos=productos, movimientos=movimientos, producto_id_filtro=producto_id_filtro)


@main_bp.route('/alertas')
@login_required
def alertas():
    if not require_area('Ventas', 'Almacen', 'Administracion'):
        flash('No tienes permiso para acceder a este modulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    ensure_operational_alerts()
    area_name = get_area_name(current_user)
    tipo = request.args.get('tipo')
    estado = request.args.get('estado')
    producto_id = request.args.get('producto_id')
    desde = request.args.get('desde')
    hasta = request.args.get('hasta')

    where = ["1=1"]
    params = []
    if tipo:
        where.append("a.nivel = %s")
        params.append(tipo)
    if estado:
        where.append("a.estado = %s")
        params.append(estado)
    if producto_id:
        where.append("a.id_producto = %s")
        params.append(producto_id)
    if desde:
        where.append("DATE(a.fecha_alerta) >= %s")
        params.append(desde)
    if hasta:
        where.append("DATE(a.fecha_alerta) <= %s")
        params.append(hasta)
    if area_name == 'Ventas':
        where.append("a.id_producto IN (SELECT id_producto FROM movimiento WHERE id_usuario = %s)")
        params.append(current_user.id)
    if area_name == 'Almacen':
        where.append("a.tipo_alerta IN ('STOCK_BAJO','CADUCIDAD')")
    if area_name == 'Administracion':
        where.append("a.nivel IN ('SISTEMA','INFORMATIVA')")

    alerts = database.query('''
        SELECT a.id_alerta, a.id_producto, p.nombre_producto, a.tipo_alerta, a.fecha_alerta,
               a.mensaje, a.atendida, a.estado, a.nivel
        FROM alerta a
        JOIN producto p ON a.id_producto = p.id_producto
        WHERE ''' + ' AND '.join(where),
        tuple(params)
    )
    productos = database.query("SELECT id_producto, nombre_producto FROM producto WHERE estado = 'ACTIVO'")
    return render_template('alertas.html', alerts=alerts, productos=productos)


@main_bp.route('/alerta/atender/<int:id>', methods=['POST'])
@login_required
def alerta_atender(id):
    database.execute("UPDATE alerta SET atendida = 1, estado = 'ATENDIDA' WHERE id_alerta = %s", (id,))
    flash('Alerta marcada como atendida.', 'success')
    return redirect(url_for('main.alertas'))


@main_bp.route('/alerta/resolver/<int:id>', methods=['POST'])
@login_required
def alerta_resolver(id):
    database.execute("UPDATE alerta SET atendida = 1, estado = 'RESUELTA' WHERE id_alerta = %s", (id,))
    flash('Alerta marcada como resuelta.', 'success')
    return redirect(url_for('main.alertas'))


@main_bp.route('/users')
@login_required
def users():
    rows = database.query('SELECT * FROM usuario')
    return render_template('users.html', users=rows)


# ==================== GESTIÓN DE USUARIOS (ADMIN ONLY) ====================

@main_bp.route('/usuarios')
@login_required
def usuarios():
    """Listar todos los usuarios (solo accesible para Administración/Gerencia)"""
    if current_user.area_id != 4:
        flash('No tienes permiso para acceder a este módulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    usuarios_list = database.query('''
        SELECT u.id_usuario, u.nombre, u.usuario_generado, a.nombre_area, u.id_area
        FROM usuario u
        LEFT JOIN area a ON u.id_area = a.id_area
        ORDER BY u.nombre
    ''')
    return render_template('usuarios_list.html', usuarios=usuarios_list)


@main_bp.route('/usuarios/crear', methods=['GET', 'POST'])
@login_required
def usuarios_crear():
    """Crear nuevo usuario (solo accesible para Administración/Gerencia)"""
    if current_user.area_id != 4:
        flash('No tienes permiso para acceder a este módulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    areas = database.query('SELECT id_area, nombre_area FROM area ORDER BY nombre_area')
    
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        apellidoP = request.form.get('apellidoP', '').strip()
        apellidoM = request.form.get('apellidoM', '').strip()
        edad = request.form.get('edad', '').strip()
        area_id = request.form.get('area_id', '').strip()
        password = request.form.get('password', '').strip()
        
        # Validaciones
        if not all([nombre, apellidoP, edad, area_id, password]):
            flash('Todos los campos son obligatorios.', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
        
        if not is_valid_text(nombre):
            flash('El nombre debe contener solo letras y espacios.', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
        
        if not is_valid_text(apellidoP) or (apellidoM and not is_valid_text(apellidoM)):
            flash('Los apellidos deben contener solo letras y espacios.', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
        
        try:
            edad = int(edad)
            if edad < 18 or edad > 35:
                flash('La edad debe estar entre 18 y 35 años.', 'danger')
                return render_template('usuarios_form.html', areas=areas, action='crear')
        except ValueError:
            flash('La edad debe ser un número válido.', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
        
        # Validar formato de contraseña: $Abc#123
        import re
        if not re.match(r'^\$[A-Za-z]{3}#[0-9]{3}$', password):
            flash('La contraseña debe tener formato: $Abc#123 (símbolo $, 3 letras, #, 3 números).', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
        
        # Generar usuario_generado: @{inicial_nombre}.{inicial_ap_p}.{inicial_ap_m}#{edad}
        inicial_nombre = nombre[0].lower()
        inicial_ap_p = apellidoP[0].lower()
        inicial_ap_m = apellidoM[0].lower() if apellidoM else 'x'
        usuario_generado = f'@{inicial_nombre}.{inicial_ap_p}.{inicial_ap_m}#{edad}'
        apellidos = f'{apellidoP} {apellidoM}'.strip()
        
        # Verificar que el usuario no exista
        existing = database.get_one(
            'SELECT id_usuario FROM usuario WHERE usuario_generado = %s',
            (usuario_generado,)
        )
        if existing:
            flash(f'El usuario {usuario_generado} ya existe.', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
        
        # Hash de contraseña
        import hashlib
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        # Insertar usuario
        try:
            database.execute('''
                INSERT INTO usuario (nombre, apellidos, usuario_generado, password_hash, id_area, primer_ingreso)
                VALUES (%s, %s, %s, %s, %s, 1)
            ''', (nombre, apellidos, usuario_generado, password_hash, area_id))
            flash(f'Usuario {usuario_generado} creado exitosamente.', 'success')
            return redirect(url_for('main.usuarios'))
        except Exception as e:
            flash(f'Error al crear usuario: {str(e)}', 'danger')
            return render_template('usuarios_form.html', areas=areas, action='crear')
    
    return render_template('usuarios_form.html', areas=areas, action='crear')


@main_bp.route('/usuarios/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def usuarios_editar(id):
    """Editar usuario (solo accesible para Administración/Gerencia)"""
    if current_user.area_id != 4:
        flash('No tienes permiso para acceder a este módulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    usuario = database.get_one('SELECT * FROM usuario WHERE id_usuario = %s', (id,))
    if not usuario:
        flash('Usuario no encontrado.', 'danger')
        return redirect(url_for('main.usuarios'))
    
    areas = database.query('SELECT id_area, nombre_area FROM area ORDER BY nombre_area')
    
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        area_id = request.form.get('area_id', '').strip()
        
        # Validaciones
        if not all([nombre, area_id]):
            flash('El nombre y área son obligatorios.', 'danger')
            return render_template('usuarios_form.html', usuario=usuario, areas=areas, action='editar')
        
        if not is_valid_text(nombre):
            flash('El nombre debe contener solo letras y espacios.', 'danger')
            return render_template('usuarios_form.html', usuario=usuario, areas=areas, action='editar')
        
        try:
            database.execute(
                'UPDATE usuario SET nombre = %s, id_area = %s WHERE id_usuario = %s',
                (nombre, area_id, id)
            )
            flash('Usuario actualizado exitosamente.', 'success')
            return redirect(url_for('main.usuarios'))
        except Exception as e:
            flash(f'Error al actualizar usuario: {str(e)}', 'danger')
            return render_template('usuarios_form.html', usuario=usuario, areas=areas, action='editar')
    
    return render_template('usuarios_form.html', usuario=usuario, areas=areas, action='editar')


@main_bp.route('/usuarios/eliminar/<int:id>', methods=['POST'])
@login_required
def usuarios_eliminar(id):
    """Eliminar usuario (solo accesible para Administración/Gerencia)"""
    if current_user.area_id != 4:
        flash('No tienes permiso para acceder a este módulo.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    usuario = database.get_one('SELECT * FROM usuario WHERE id_usuario = %s', (id,))
    if not usuario:
        flash('Usuario no encontrado.', 'danger')
        return redirect(url_for('main.usuarios'))
    
    # No permitir eliminar al usuario actual
    if id == current_user.id:
        flash('No puedes eliminar tu propia cuenta.', 'danger')
        return redirect(url_for('main.usuarios'))
    
    try:
        database.execute('DELETE FROM usuario WHERE id_usuario = %s', (id,))
        flash(f'Usuario {usuario["usuario_generado"]} eliminado exitosamente.', 'success')
    except Exception as e:
        flash(f'Error al eliminar usuario: {str(e)}', 'danger')
    
    return redirect(url_for('main.usuarios'))
