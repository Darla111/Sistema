import mysql.connector
from mysql.connector import pooling, Error
from flask import current_app
from config import Config

_pool = None

def init_app(app=None):
    """
    Inicializa el pool de conexiones a MySQL usando los parámetros de Config.
    Debe llamarse en app/__init__.py después de crear la aplicación Flask.
    """
    global _pool
    cfg = {
        'host': Config.DB_HOST,
        'user': Config.DB_USER,
        'password': Config.DB_PASSWORD,
        'database': Config.DB_NAME,
        'port': Config.DB_PORT,
    }
    try:
        _pool = pooling.MySQLConnectionPool(
            pool_name='app_pool',
            pool_size=5,
            pool_reset_session=True,
            **cfg
        )
        if app:
            app.logger.info(
                f'✓ MySQL pool inicializado: {Config.DB_USER}@{Config.DB_HOST}:{Config.DB_PORT}/{Config.DB_NAME}'
            )
    except Error as e:
        if app:
            app.logger.error(
                f'✗ Error al crear pool MySQL: {e}\n'
                f'  Verifica credenciales: {Config.DB_USER}@{Config.DB_HOST}:{Config.DB_PORT}/{Config.DB_NAME}'
            )
        raise


def get_conn():
    if _pool is None:
        raise RuntimeError('Connection pool is not initialized. Call init_app(app)')
    return _pool.get_connection()


def query(sql, params=None):
    """
    Ejecuta una consulta SELECT y devuelve todas las filas como diccionarios.
    """
    conn = get_conn()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute(sql, params or ())
        rows = cursor.fetchall()
        return rows
    except Error as e:
        raise Exception(f'Error en query: {e}\nSQL: {sql}') from e
    finally:
        cursor.close()
        conn.close()


def get_one(sql, params=None):
    rows = query(sql, params)
    return rows[0] if rows else None


def execute(sql, params=None):
    """
    Ejecuta una inserción, actualización o eliminación, y confirma la transacción.
    Devuelve el lastrowid (para inserciones).
    """
    conn = get_conn()
    cursor = conn.cursor()
    try:
        cursor.execute(sql, params or ())
        conn.commit()
        return cursor.lastrowid
    except Error as e:
        conn.rollback()
        raise Exception(f'Error en execute: {e}\nSQL: {sql}') from e
    finally:
        cursor.close()
        conn.close()
