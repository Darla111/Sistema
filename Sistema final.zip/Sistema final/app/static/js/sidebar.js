document.addEventListener('DOMContentLoaded', function () {
  const toggleBtn = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const content = document.getElementById('content');
  
  // Toggle sidebar on button click
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function () {
      sidebar.classList.toggle('collapsed');
    });
  }
  
  // Active link based on current URL
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.sidebar-menu .nav-link');
  
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (currentPath.includes(href) || (href === '/' && currentPath === '/')) {
      link.classList.add('active');
    }
  });
  
  // Close sidebar on mobile when link is clicked
  if (window.innerWidth < 768) {
    navLinks.forEach(link => {
      link.addEventListener('click', function () {
        sidebar.classList.add('collapsed');
      });
    });
  }
});

// Handle window resize
window.addEventListener('resize', function () {
  const sidebar = document.getElementById('sidebar');
  if (window.innerWidth > 768 && sidebar.classList.contains('collapsed')) {
    sidebar.classList.remove('collapsed');
  }
});
