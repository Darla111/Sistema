#!/usr/bin/env python
"""
Script para validar que no hay errores de template de Jinja
"""
import sys
sys.path.insert(0, '/c/Users/beren/OneDrive/Desktop/Proyecto PLF/Sistema final')

from app import create_app
from flask import render_template_string

app = create_app()

with app.app_context():
    try:
        print("✓ Testing login.html...")
        from flask import render_template
        # Just test if the templates load without error
        render_template('login.html')
        print("  ✓ login.html carga correctamente")
        
        print("✓ Testing register.html...")
        render_template('register.html', areas=[])
        print("  ✓ register.html carga correctamente")
        
        print("✓ Testing welcome.html...")
        render_template('welcome.html', user_area=None)
        print("  ✓ welcome.html carga correctamente")
        
        print("✓ Testing dashboard.html...")
        render_template('dashboard.html')
        print("  ✓ dashboard.html carga correctamente")
        
        print("\n✅ TODOS LOS TEMPLATES VÁLIDOS - SIN ERRORES DE JINJA")
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
