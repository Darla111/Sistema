from app import create_app
from app import database
import hashlib

app = create_app()

def create_admin():
    nombre = input('Nombre: ')
    apellidos = input('Apellidos: ')
    edad = input('Edad: ')
    area_id = input('Area id: ')
    password = input('Password (mínimo 8 caracteres): ')
    usuario_generado = input('Usuario generado (ej: @j.p.l#23) o deja vacío para generar: ')
    if not usuario_generado:
        parts = apellidos.split()
        usuario_generado = f"@{nombre[0].lower()}.{parts[0][0].lower() if parts else ''}.{parts[1][0].lower() if len(parts)>1 else ''}#{edad}"

    password_hash = hashlib.sha256(password.encode('utf-8')).hexdigest()
    with app.app_context():
        database.execute('INSERT INTO usuario (nombre, apellidos, edad, area_id, usuario_generado, password_hash, primer_ingreso) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                         (nombre, apellidos, edad, area_id, usuario_generado, password_hash, 1))
    print('Usuario creado:', usuario_generado)


if __name__ == '__main__':
    create_admin()
