#!/usr/bin/env python
"""
SCRIPT DE VALIDACIÓN DEL SISTEMA
Verifica que todos los componentes funcionan correctamente
"""
import hashlib
from app import create_app
from app.database import query, get_one, execute

app = create_app()

print("\n" + "=" * 70)
print("  VALIDACIÓN DEL SISTEMA DE GESTIÓN EMPRESARIAL")
print("=" * 70)

with app.app_context():
    # 1. Test conexión
    print("\n[1] CONEXIÓN A LA BASE DE DATOS")
    print("-" * 70)
    try:
        result = get_one('SELECT COUNT(*) AS total FROM producto')
        print(f"  ✓ Conexión exitosa")
        print(f"  ✓ Total de productos: {result['total']}")
    except Exception as e:
        print(f"  ✗ Error: {e}")
        
    # 2. Test autenticación
    print("\n[2] AUTENTICACIÓN")
    print("-" * 70)
    try:
        user = get_one('SELECT * FROM usuario WHERE usuario_generado = %s', ('@a.l.g#28',))
        if user:
            print(f"  ✓ Usuario encontrado: {user['usuario_generado']}")
            print(f"    Nombre: {user['nombre']} {user['apellidos']}")
            print(f"    Área: {user['id_area']}")
            
            # Verificar contraseña
            test_pwd = 'password123'
            test_hash = hashlib.sha256(test_pwd.encode()).hexdigest()
            if test_hash == user['password_hash']:
                print(f"  ✓ Contraseña verificada correctamente")
            else:
                print(f"  ✗ Error en hash de contraseña")
        else:
            print(f"  ✗ Usuario no encontrado")
    except Exception as e:
        print(f"  ✗ Error: {e}")
    
    # 3. Test CRUD Productos
    print("\n[3] CRUD - PRODUCTOS")
    print("-" * 70)
    try:
        productos = query('SELECT id_producto, nombre_producto, stock_actual, stock_minimo FROM producto')
        print(f"  ✓ Total de productos: {len(productos)}")
        for p in productos:
            estado = "BAJO" if p['stock_actual'] < p['stock_minimo'] else "OK"
            print(f"    - {p['nombre_producto']}: {p['stock_actual']}/{p['stock_minimo']} [{estado}]")
    except Exception as e:
        print(f"  ✗ Error: {e}")
    
    # 4. Test Áreas
    print("\n[4] ÁREAS DEL SISTEMA")
    print("-" * 70)
    try:
        areas = query('SELECT id_area, nombre_area FROM area')
        print(f"  ✓ Total de áreas: {len(areas)}")
        for a in areas:
            print(f"    - {a['nombre_area']} (ID: {a['id_area']})")
    except Exception as e:
        print(f"  ✗ Error: {e}")
    
    # 5. Test Empleados
    print("\n[5] EMPLEADOS")
    print("-" * 70)
    try:
        empleados = query('SELECT COUNT(*) AS total FROM empleado')
        print(f"  ✓ Total de empleados: {empleados[0]['total']}")
    except Exception as e:
        print(f"  ✗ Error: {e}")
    
    # 6. Test Movimientos
    print("\n[6] MOVIMIENTOS")
    print("-" * 70)
    try:
        movimientos = query('SELECT COUNT(*) AS total FROM movimiento')
        print(f"  ✓ Total de movimientos registrados: {movimientos[0]['total']}")
    except Exception as e:
        print(f"  ✗ Error: {e}")
    
    # 7. Test Alertas
    print("\n[7] ALERTAS")
    print("-" * 70)
    try:
        alertas = query('SELECT * FROM vw_alertas_activas')
        print(f"  ✓ Alertas activas: {len(alertas)}")
        if alertas:
            for a in alertas[:3]:  # Mostrar solo primeras 3
                print(f"    - {a}")
    except Exception as e:
        print(f"  ✗ Error: {e}")
    
    # 8. Test OLAP Views
    print("\n[8] VISTAS OLAP (INTELIGENCIA DE NEGOCIOS)")
    print("-" * 70)
    try:
        mov_dia = query('SELECT * FROM vw_movimientos_por_dia LIMIT 5')
        print(f"  ✓ vw_movimientos_por_dia: {len(mov_dia)} registros")
        
        mov_prod = query('SELECT * FROM vw_movimientos_por_producto LIMIT 5')
        print(f"  ✓ vw_movimientos_por_producto: {len(mov_prod)} registros")
        
        alertas_activas = query('SELECT * FROM vw_alertas_activas LIMIT 5')
        print(f"  ✓ vw_alertas_activas: {len(alertas_activas)} registros")
    except Exception as e:
        print(f"  ✗ Error: {e}")

print("\n" + "=" * 70)
print("  ✓ VALIDACIÓN COMPLETADA")
print("=" * 70)
print("\n💡 DATOS DE PRUEBA:")
print("  Usuario: @a.l.g#28")
print("  Contraseña: password123")
print("\n📍 ACCEDIR AL SISTEMA:")
print("  URL: http://localhost:5000/login")
print("=" * 70 + "\n")
