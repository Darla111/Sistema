#!/usr/bin/env python
"""Check database structure and existing data"""
from app import create_app
from app.database import query

app = create_app()

with app.app_context():
    print("=" * 60)
    print("TABLAS EN LA BASE DE DATOS")
    print("=" * 60)
    tables = query('SHOW TABLES')
    for t in tables:
        table_name = list(t.values())[0]
        print(f"  ✓ {table_name}")
    
    print("\n" + "=" * 60)
    print("ESTRUCTURA: TABLA USUARIO")
    print("=" * 60)
    columns = query('DESCRIBE usuario')
    for col in columns:
        print(f"  {col['Field']}: {col['Type']} ({col['Null']})")
    
    print("\n" + "=" * 60)
    print("CONTENIDO: TABLA USUARIO")
    print("=" * 60)
    usuarios = query('SELECT * FROM usuario')
    if usuarios:
        for u in usuarios:
            print(f"  {u}")
    else:
        print("  (Sin usuarios)")
    
    print("\n" + "=" * 60)
    print("ÁREAS")
    print("=" * 60)
    areas = query('SELECT * FROM area')
    if areas:
        for a in areas:
            print(f"  {a}")
    else:
        print("  (Sin áreas)")
    
    print("\n" + "=" * 60)
    print("PRODUCTOS")
    print("=" * 60)
    productos = query('SELECT * FROM producto')
    if productos:
        print(f"  Total: {len(productos)} productos")
        for p in productos:
            print(f"    {p}")
    else:
        print("  (Sin productos)")
    
    print("\n" + "=" * 60)


