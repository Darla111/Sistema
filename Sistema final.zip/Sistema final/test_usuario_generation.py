#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test de Generación Automática de Usuario
Verifica que la generación del usuario funcione correctamente
"""

import sys
import re

def test_usuario_generation():
    """Prueba la generación de usuario con el nuevo formato"""
    print("\n" + "="*70)
    print("🔧 Test: Generación Automática de Usuario")
    print("="*70)
    
    test_cases = [
        {
            'nombre': 'Berenice',
            'apellidos': 'Chávez Bedolla',
            'edad': 22,
            'esperado': '@b.c.b_22'
        },
        {
            'nombre': 'Juan',
            'apellidos': 'García López',
            'edad': 25,
            'esperado': '@j.g.l_25'
        },
        {
            'nombre': 'María',
            'apellidos': 'Rodríguez Pérez',
            'edad': 30,
            'esperado': '@m.r.p_30'
        },
        {
            'nombre': 'Carlos',
            'apellidos': 'López',  # Solo un apellido
            'edad': 28,
            'esperado': '@c.l.x_28'
        },
    ]
    
    print("\nCasos de prueba:")
    print("-" * 70)
    
    all_passed = True
    for i, test in enumerate(test_cases, 1):
        nombre = test['nombre']
        apellidos = test['apellidos']
        edad = test['edad']
        esperado = test['esperado']
        
        # Generar usuario automáticamente
        parts = apellidos.split()
        ap_p = parts[0] if parts else ''
        ap_m = parts[1] if len(parts) > 1 else ''
        
        inicial_nombre = nombre[0].lower() if nombre else ''
        inicial_ap_p = ap_p[0].lower() if ap_p else ''
        inicial_ap_m = ap_m[0].lower() if ap_m else 'x'
        
        usuario_generado = f"@{inicial_nombre}.{inicial_ap_p}.{inicial_ap_m}_{edad}"
        
        # Comparar
        if usuario_generado == esperado:
            print(f"✅ Test {i}: PASS")
            print(f"   Entrada: {nombre} {apellidos}, {edad} años")
            print(f"   Usuario: {usuario_generado}")
        else:
            print(f"❌ Test {i}: FAIL")
            print(f"   Entrada: {nombre} {apellidos}, {edad} años")
            print(f"   Esperado: {esperado}")
            print(f"   Obtenido: {usuario_generado}")
            all_passed = False
        print()
    
    return all_passed

def test_password_validation():
    """Prueba validación de contraseñas"""
    print("\n" + "="*70)
    print("🔧 Test: Validación de Contraseñas")
    print("="*70)
    
    PASSWORD_PATTERN = r'^\$[A-Za-z]{3}#[0-9]{3}$'
    
    test_cases = [
        ('$Abc#123', True, 'Válida'),
        ('$abc#123', True, 'Válida (minúsculas)'),
        ('$ABC#123', True, 'Válida (mayúsculas)'),
        ('$Ab#123', False, 'Inválida: 2 letras'),
        ('$Abc123', False, 'Inválida: sin #'),
        ('Abc#123', False, 'Inválida: sin $'),
        ('$Abc#12', False, 'Inválida: 2 números'),
    ]
    
    print("\nCasos de validación:")
    print("-" * 70)
    
    all_passed = True
    for pwd, should_be_valid, descripcion in test_cases:
        is_valid = bool(re.match(PASSWORD_PATTERN, pwd))
        
        if is_valid == should_be_valid:
            print(f"✅ '{pwd}': {descripcion}")
        else:
            print(f"❌ '{pwd}': {descripcion} (esperado: {'válida' if should_be_valid else 'inválida'}, obtenido: {'válida' if is_valid else 'inválida'})")
            all_passed = False
    
    print()
    return all_passed

def test_age_validation():
    """Prueba validación de edad"""
    print("\n" + "="*70)
    print("🔧 Test: Validación de Edad")
    print("="*70)
    
    test_cases = [
        (20, False, 'Menor a 21 (rechazada)'),
        (21, True, 'Exactamente 21 (aceptada)'),
        (22, True, '22 años (aceptada)'),
        (100, True, '100 años (aceptada)'),
        (101, True, '101 años (aceptada, validar max en formulario)'),
    ]
    
    print("\nCasos de validación:")
    print("-" * 70)
    
    all_passed = True
    for edad, should_pass, descripcion in test_cases:
        is_valid = edad >= 21
        
        if is_valid == should_pass:
            print(f"✅ Edad {edad}: {descripcion}")
        else:
            print(f"❌ Edad {edad}: {descripcion} (validación fallida)")
            all_passed = False
    
    print()
    return all_passed

def main():
    """Ejecuta todos los tests"""
    print("\n\n")
    print("#" * 70)
    print("#" + " "*68 + "#")
    print("#  TEST DE GENERACIÓN AUTOMÁTICA DE USUARIO" + " "*27 + "#")
    print("#" * 70)
    
    results = []
    results.append(("Generación de Usuario", test_usuario_generation()))
    results.append(("Validación de Contraseña", test_password_validation()))
    results.append(("Validación de Edad", test_age_validation()))
    
    # Resumen
    print("\n" + "="*70)
    print("📊 RESUMEN")
    print("="*70)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")
    
    total_passed = sum(1 for _, result in results if result)
    total = len(results)
    
    print("\n" + "="*70)
    print(f"🎯 RESULTADO: {total_passed}/{total} tests exitosos\n")
    
    if total_passed == total:
        print("✅ Toda la lógica de validación y generación funciona correctamente")
        print("✅ Sistema listo para registro de nuevos usuarios\n")
        return 0
    else:
        print(f"❌ {total - total_passed} test(s) fallaron\n")
        return 1

if __name__ == '__main__':
    sys.exit(main())
