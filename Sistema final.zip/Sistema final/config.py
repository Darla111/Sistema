import os

class Config:
    """
    Configuración centralizada de la aplicación Flask.
    Lee parámetros de base de datos desde variables de entorno o usa valores por defecto.
    """
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')

    # ===== DATABASE CONFIGURATION =====
    # Parámetros de conexión a MySQL usando mysql.connector
    # Los valores por defecto corresponden a la base de datos existente
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = int(os.environ.get('DB_PORT', 3306))
    DB_USER = os.environ.get('DB_USER', 'BereniceCB')  # Usuario de MySQL
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '1234')  # Contraseña de MySQL
    DB_NAME = os.environ.get('DB_NAME', 'sistema_gestion_empresarial')  # Base de datos existente

    # ===== SQLALCHEMY (si se usa en el futuro) =====
    # URI para SQLAlchemy (mantenerlo consistente, aunque usamos mysql-connector directamente)
    SQLALCHEMY_DATABASE_URI = (
        f"mysql+mysqlconnector://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ===== LOGGING =====
    FLASK_ENV = os.environ.get('FLASK_ENV', 'development')
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
